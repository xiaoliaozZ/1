from FCN import FCN
from dataset import ISBI_Loader
from torch import optim
import torch.nn as nn
import torch
import matplotlib.pyplot as plt
import numpy as np


def train_net(net, device, data_path, epochs=5, batch_size=10, lr=0.01):
    # 加载训练集
    isbi_dataset = ISBI_Loader(data_path)
    train_loader = torch.utils.data.DataLoader(dataset=isbi_dataset,
                                               batch_size=batch_size,
                                               shuffle=True)

    # 定义Adam优化器（或根据您的需要选择其他优化器）
    optimizer = optim.Adam(net.parameters(), lr=lr, weight_decay=1e-8)

    # 定义Loss算法
    criterion = nn.BCEWithLogitsLoss()

    # best_loss统计，初始化为正无穷
    best_loss = float('inf')
    # 用于记录每个epoch的损失
    epoch_losses = []

    for epoch in range(epochs):
        net.train()  # 设置模型为训练模式
        epoch_loss = 0.0  # 初始化epoch损失为0

        for image, label in train_loader:
            optimizer.zero_grad()  # 清零梯度
            image = image.to(device=device, dtype=torch.float32)
            label = label.to(device=device, dtype=torch.float32)
            pred = net(image)
            loss = criterion(pred, label)
            print('Loss/train', loss.item())
            loss.backward()  # 反向传播
            optimizer.step()  # 更新权重

            epoch_loss += loss.item() * image.size(0)  # 累加每个batch的总损失

        # 计算epoch的平均损失
        epoch_loss /= len(train_loader.dataset)
        epoch_losses.append(epoch_loss)
        print(f'Epoch {epoch + 1}/{epochs}, Average Loss: {epoch_loss:.4f}')

        # 检查并更新最佳损失（如果需要）
        if epoch_loss < best_loss:
            best_loss = epoch_loss
            # 保存最佳模型
            torch.save(net.state_dict(), 'best_model.pth')

    # 绘制损失曲线（在所有epoch结束后）
    plt.figure(figsize=(10, 6))
    plt.plot(np.arange(1, epochs + 1), epoch_losses, label='Train Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.title('Training Loss Curve')
    plt.legend()
    plt.grid(True)
    plt.savefig('training_loss_curve.png')
    plt.show()


if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net = FCN(n_channels=1, n_classes=1)
    net.to(device=device)
    data_path = "D:/pythonProject6/ChestXRay2017/chest_xray/train"
    train_net(net, device, data_path)




from FCN import FCN
from dataset import ISBI_Loader
from torch import optim
import torch.nn as nn
import torch
import matplotlib.pyplot as plt
import numpy as np
import optuna


def train_net(net, device, data_path, epochs=5, batch_size=10, lr=0.001, weight_decay=1e-8):
    # 加载训练集
    isbi_dataset = ISBI_Loader(data_path)
    train_loader = torch.utils.data.DataLoader(dataset=isbi_dataset,
                                               batch_size=batch_size,
                                               shuffle=True)

    # 定义Adam优化器
    optimizer = optim.Adam(net.parameters(), lr=lr, weight_decay=weight_decay)

    # 定义Loss算法
    criterion = nn.BCEWithLogitsLoss()

    # 训练过程
    net.train()  # 设置模型为训练模式
    epoch_losses = []  # 用于记录每个epoch的损失

    for epoch in range(epochs):
        epoch_loss = 0.0  # 初始化epoch损失为0

        for image, label in train_loader:
            optimizer.zero_grad()  # 清零梯度
            image = image.to(device=device, dtype=torch.float32)
            label = label.to(device=device, dtype=torch.float32)
            pred = net(image)
            loss = criterion(pred, label)
            loss.backward()  # 反向传播
            optimizer.step()  # 更新权重

            epoch_loss += loss.item() * image.size(0)  # 累加每个batch的总损失

        # 计算epoch的平均损失
        epoch_loss /= len(train_loader.dataset)
        epoch_losses.append(epoch_loss)
        print(f'Epoch {epoch + 1}/{epochs}, Average Loss: {epoch_loss:.4f}')

    # 返回最后一个epoch的平均损失作为最终损失（或者你可以选择返回所有epoch的平均损失）
    final_loss = epoch_losses[-1] if epoch_losses else float('inf')
    return final_loss


def objective(trial):
    # 从Optuna的搜索空间中采样超参数
    lr = trial.suggest_float('lr', 1e-5, 1e-1, log=True)
    weight_decay = trial.suggest_float('weight_decay', 1e-9, 1e-3, log=True)

    # 初始化模型和设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net = FCN(n_channels=1, n_classes=1).to(device)

    # 训练模型并获取最终损失
    data_path = "D:/pythonProject6/ChestXRay2017/chest_xray/train"
    loss = train_net(net, device, data_path, lr=lr, weight_decay=weight_decay)

    # 返回损失值作为Optuna优化的目标
    return loss

if __name__ == "__main__":
    study = optuna.create_study(direction='minimize')  # 创建研究实例，目标是最小化损失
    study.optimize(objective, n_trials=10)  # 执行100次试验来搜索最优超参数

    # 输出最优超参数和对应的损失值
    print("Best hyperparameters found: ", study.best_params)
    print("Best loss: ", study.best_value)
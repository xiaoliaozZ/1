import torch
import cv2
import os
import glob
from torch.utils.data import Dataset
import random

class ISBI_Loader(Dataset):
    def __init__(self, data_path):
        self.data_path = data_path
        self.images = []
        self.labels = []

        # 遍历NORMAL和PNEUMONIA文件夹，添加图像路径和标签
        for label, folder in enumerate(['NORMAL', 'PNEUMONIA']):
            folder_path = os.path.join(data_path, folder)
            for img_path in glob.glob(os.path.join(folder_path, '*.jpeg')):
                self.images.append(img_path)
                self.labels.append(label)  # 0 for NORMAL, 1 for PNEUMONIA

    def augment(self, image, flipCode):
        # 确保flipCode是有效的
        valid_flip_codes = [-1, 0, 1]
        if flipCode not in valid_flip_codes:
            flipCode = random.choice(valid_flip_codes)  # 如果选择了无效的flipCode，则随机选择一个有效的
        return cv2.flip(image, flipCode)

    def __getitem__(self, index):
        image_path = self.images[index]
        label = self.labels[index]

        # 读取图像
        image = cv2.imread(image_path)
        if image is None:
            raise FileNotFoundError(f"Image not found at path: {image_path}")

        # 应用图像增强
        flipCode = random.choice([-1, 0, 1])  # -1: 水平翻转, 0: 不翻转, 1: 垂直翻转
        image = self.augment(image, flipCode)
        label = self.augment(label, flipCode)

        # 转换为灰度图（如果需要）
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # 调整图像大小到固定尺寸
        target_size = (256, 256)  # 您可以根据需要调整这个尺寸
        image = cv2.resize(image, target_size, interpolation=cv2.INTER_AREA)
        label = cv2.resize(label, target_size, interpolation=cv2.INTER_AREA)

        # 将图像转换为张量并归一化
        image = torch.tensor(image, dtype=torch.float32)
        label = torch.tensor(label, dtype=torch.float32)
        image = image / 255.0  # 归一化到 [0, 1] 范围
        label = label / 255.0

        # 调整形状以匹配PyTorch的输入要求（C x H x W），这里C=1表示灰度图
        image = image.reshape(1, *target_size)
        label = image.reshape(1, *target_size)

        return image, label

    def __len__(self):
        return len(self.images)

# 测试代码
if __name__ == "__main__":
    data_path = "D:/pythonProject6/ChestXRay2017/chest_xray/train"
    isbi_dataset = ISBI_Loader(data_path)
    print("数据个数：", len(isbi_dataset))
    train_loader = torch.utils.data.DataLoader(dataset=isbi_dataset, batch_size=2, shuffle=True)
    for images, labels in train_loader:
        print(images.shape)  # 应该输出类似 [batch_size, 1, height, width]
        print(labels.shape)  # 应该输出类似 [batch_size]
        break  # 只打印一批数据以进行测试
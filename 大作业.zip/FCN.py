import torch.nn as nn
import torch.nn.functional as F


class FCN(nn.Module):
    def __init__(self, n_channels, n_classes):
        super(FCN, self).__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes

        # Define FCN layers with desired output stride
        self.conv1 = nn.Conv2d(n_channels, 64, kernel_size=3, padding=1)
        self.pool1 = nn.MaxPool2d(2, 2)  # 第一个池化层，缩小尺寸为原来的1/2
        self.conv2 = nn.Conv2d(64, 128, kernel_size=3, padding=1)
        self.pool2 = nn.MaxPool2d(2, 2)  # 第二个池化层，缩小尺寸为原来的1/4
        self.conv3 = nn.Conv2d(128, 256, kernel_size=3, padding=1)
        self.pool3 = nn.MaxPool2d(2, 2)  # 第三个池化层，缩小尺寸为原来的1/8
        self.conv4 = nn.Conv2d(256, 512, kernel_size=3, padding=1)
        self.pool4 = nn.MaxPool2d(2, 2)  # 第四个池化层，缩小尺寸为原来的1/16
        self.conv5 = nn.Conv2d(512, 512, kernel_size=3, padding=1)
        self.pool5 = nn.MaxPool2d(2, 2)  # 第五个池化层，缩小尺寸为原来的1/32

        # 修改最后一个卷积层的输出通道数和核大小，确保输出与标签尺寸一致
        self.conv6 = nn.Conv2d(512, n_classes, kernel_size=1)

        # 添加上采样层，将特征图大小恢复到输入图像的大小
        self.upsample = nn.Upsample(scale_factor=32, mode='bilinear', align_corners=True)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = self.pool1(x)
        x = F.relu(self.conv2(x))
        x = self.pool2(x)
        x = F.relu(self.conv3(x))
        x = self.pool3(x)
        x = F.relu(self.conv4(x))
        x = self.pool4(x)
        x = F.relu(self.conv5(x))
        x = self.pool5(x)
        x = self.conv6(x)
        x = self.upsample(x)  # 进行上采样
        return x


if __name__ == '__main__':
    net = FCN(n_channels=1, n_classes=1)
    print(net)

    # # Output the parameters and sizes
    # for name, param in net.named_parameters():
    #     print(f'Parameter name: {name}, Size: {param.size()}')
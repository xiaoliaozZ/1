import torch
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from dataset import ISBI_Loader
from FCN import FCN


def evaluate_net(net, device, data_path, batch_size=10):
    # 加载测试集
    test_dataset = ISBI_Loader(data_path)
    test_loader = torch.utils.data.DataLoader(dataset=test_dataset,
                                              batch_size=batch_size,
                                              shuffle=False)

    net.eval()  # 设置模型为评估模式
    all_preds = []
    all_labels = []

    with torch.no_grad():  # 禁用梯度计算
        for image, label in test_loader:
            image = image.to(device=device, dtype=torch.float32)
            # 注意：对于FCN等全卷积网络，输出可能是多通道的，需要处理成二分类输出
            # 假设您的FCN输出一个单通道的概率图，我们需要对其进行二值化处理
            pred = net(image)
            pred = torch.sigmoid(pred).squeeze(1)  # 假设输出是单通道的，并去掉通道维
            pred_binary = (pred > 0.5).float()  # 二值化处理


            label = label.to(device=device, dtype=torch.float32)
            label = label.squeeze(1)  # 假设标签也是单通道的（尽管之前代码有误）
            label = (label > 0).float()  # 将标签转换为二进制（如果存在非0即视为正类）

            # 展开pred_binary和label以收集所有预测和真实标签
            all_preds.append(pred_binary.cpu().numpy().flatten())
            all_labels.append(label.cpu().numpy().flatten())

    # 将所有预测和标签合并为一个数组
    all_preds = np.concatenate(all_preds)
    all_labels = np.concatenate(all_labels)

    # 计算评价指标
    accuracy = accuracy_score(all_labels, all_preds)
    precision = precision_score(all_labels, all_preds)
    recall = recall_score(all_labels, all_preds)
    f1 = f1_score(all_labels, all_preds)

    print(f'精准率: {accuracy:.4f}')
    print(f'精准度: {precision:.4f}')
    print(f'召回率: {recall:.4f}')
    print(f'F1分数: {f1:.4f}')

if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net = FCN(n_channels=1, n_classes=1)
    net.load_state_dict(torch.load('best_model.pth', map_location=device))
    net.to(device=device)
    data_path = "D:/pythonProject6/ChestXRay2017/chest_xray/test"  # 注意使用测试集路径
    evaluate_net(net, device, data_path)